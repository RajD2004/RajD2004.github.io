#include "share.cpp"
#include <iostream>
#include <string>

using namespace std;

int main() {
    
    string word1, word2, word3;
    
    getline(cin, word1); 
    getline(cin, word2);
    getline(cin, word3);

    const string& word1_ref = word1; 
    const string word2_copy = word2;
    const string* word3_ptr = &word3;

    string output_str = SharedLetters(word1_ref, word2_copy, word3_ptr);

    cout << output_str << endl;

    return 0;
}