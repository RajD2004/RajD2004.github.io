#pragma once
#include <string>

using namespace std;

string Capitalize(string& word);

std::string largest_word(std::string const& word1, std::string const word2, std::string const* word3);

std::string SharedLetters(std::string const& word1, std::string const word2, std::string const* word3); 