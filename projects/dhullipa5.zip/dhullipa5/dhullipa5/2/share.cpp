#include "share.h"
#include <string>
#include <stdexcept>

using namespace std;


string largest_word(string const& word1, string const word2, string const* word3){
    
    if(word1.size() >= word2.size() && word1.size() >= word3->size()) return word1;
    else if(word2.size() >= word1.size() && word2.size() >= word3->size()) return word2; 
    else return *word3;
}


string SharedLetters(string const& word1, string const word2, string const* word3){
    string final_output;
    string large_word = largest_word(word1, word2, word3);
    for(int i = 0; i < large_word.size(); ++i){
        try{
            char letter1 = word1.at(i);
            char letter2 = word2.at(i);
            char letter3 = word3->at(i);

            if(letter1 == letter2 && letter2 == letter3) final_output += "3, ";

            else if((letter1 == letter2 && letter1 != letter3) ||(letter1 == letter3 && letter1 != letter2) ||(letter2 == letter3 && letter2 != letter1)) final_output += "1, ";

            else final_output += "0, ";
        }
        catch(out_of_range& e){
            if(i >= word1.size() || i >= word2.size() || i >= word3->size()){
                if(i >= word1.size() && i >= word2.size()) final_output += "0, ";
                else if(i >= word2.size() && i >= word3->size()) final_output += "0, ";
                else if(i >= word1.size() && i >= word3->size()) final_output += "0, ";
                else if (i >= word1.size() && i < word2.size() && i < word3->size()){
                    if(word2.at(i) == word3->at(i)) final_output += "1, ";
                    else final_output += "0, ";
                }
                else if (i >= word2.size() && i < word1.size() && i < word3->size()){
                    if(word1.at(i) == word3->at(i)) final_output += "1, ";
                    else final_output += "0, ";
                }
                else if (i >= word3->size() && i < word1.size() && i < word2.size()){
                    if(word1.at(i) == word2.at(i)) final_output += "1, ";
                    else final_output += "0, ";
                }
            }
        }
    }
    return final_output;
}