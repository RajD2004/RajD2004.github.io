#pragma once
#include <string>
#include <vector>

using namespace std; 


bool char_in_str(string const& str, char const& ch); 

vector<int> char_instance_str(string word, char ch);

string WordleResponse(string const& secret_word, string const& guess); 