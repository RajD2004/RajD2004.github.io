//Wordle
#include <iostream>
#include <string>
#include <cctype>
#include "WordleResponse.cpp"

using namespace std; 


int main(){
    string guess_word; 
    string secret_word;
    bool game_over = false; 
    int num_guess{0};

    cout << "Give me a secret word: " << endl;
    getline(cin, secret_word); 
    Capitalize(secret_word);

    while(true){
        if(!game_over && num_guess < 6){
            cout << "Give me a guess: " << endl;
            getline(cin, guess_word);
            Capitalize(guess_word);

            if(guess_word == secret_word){
                cout << "You Win." << endl;
                break;
            }

            else{
                string const& secret_word_ref = secret_word;
                string const& guess_word_ref = guess_word;

                string wordle_output = WordleResponse(secret_word_ref, guess_word_ref);

                cout << wordle_output << endl;
            }
            ++num_guess; 
            
        }
        if(num_guess >= 6){
            cout << "You Lose." << endl;
            break;
        }
         
    }

    return 0;
}