#include <iostream>
#include <string>
#include <stdexcept>
#include <cctype>

using namespace std; 

void Capitalize(string& word){
    for(int index = 0; index < word.size(); ++index){
        word[index] = toupper(word[index]);
    }
}

bool char_in_str(string const& str, char const& ch){
    for (auto const& c: str){
        if(c == ch){
            return true;
        }
    }
    return false;
}

int char_instance_str(string word, char ch){
    int num_occurances = 0;
    for(int index = 0; index < word.size(); ++index){
        if (word[index] == ch){
            num_occurances += 1;
            }
        }
    return num_occurances; 
}


string WordleResponse(string const& secret_word, string const& guess){
    string output_word; 
    int num_times_inserted = 0;
    bool word_used = true;
    for(int index = 0; index < secret_word.size(); ++index){
        if(secret_word[index] == guess[index]){
            output_word += secret_word[index];
        }
        else{
            auto num_occurances =  char_instance_str(secret_word, guess[index]);
            if(char_in_str(secret_word, guess[index])){
                
                output_word+= "?";
            }
            else output_word += ".";
        }
    }
    return output_word;
}