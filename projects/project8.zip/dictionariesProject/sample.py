def main():
    fp = open_file()
    states_dictionary = read_file(fp)
    max_gdpp, max_pip = get_max(states_dictionary)
    min_gdpp, min_pip = get_min(states_dictionary)
    print_info(max_gdpp, max_pip, min_gdpp, min_pip)
    
    pass