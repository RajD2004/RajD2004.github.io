from matplotlib import pyplot as plt 
import pylab 

def open_file():
    file_name = input("Enter file name: ")
    done = False
    while not done:
        try:
            file_pointer = open(file_name,'r')
            done = True
        except FileNotFoundError:
            file_name = input("Enter file name: ")
            continue
    return file_pointer

def read_file(fp):
    
    
    region_list = []
    main_list = []
    state_dict = {}
    keys_list = []
    main_dict = {}
    i = 0
    main_items_list = []
    

    for line in fp:
        line = line.strip()
        line_list = line.split(',')
        main_list.append(line_list)
    
    for lst in main_list:
        region_list.append(lst[1].lower())
    
    region = input("Enter the region: ")
    while region not in region_list:
        print("ERROR, INCORRECT REGION")
        region = input("Enter the region: ")
        continue

    for lst in main_list[1:]:
        if lst[1].lower() == region.lower():
            lst.pop(1)
            state_key = lst.pop(0)
            state_dict[state_key] = lst
        elif region.lower() == 'all':
            lst.pop(1)
            state_key = lst.pop(0)
            state_dict[state_key] = lst
        

    for key in state_dict:
        lst = state_dict.get(key)
        items_list = []
        for value in lst:
            value = float(value)
            items_list.append(value)
        GDPp = round((items_list[1]*1000000000)/(items_list[0]*1000000),2)
        PIp = round((items_list[2]*1000000000)/(items_list[0]*1000000),2)
        items_list.append(GDPp)
        items_list.append(PIp)
        main_items_list.append(items_list)

    for key in state_dict:
        keys_list.append(key)
    
    while i < len(state_dict):
        main_dict[keys_list[i]] = main_items_list[i]
        i += 1
    
    fp.close()
    
    return main_dict

def get_max(state_dict):
    gdpp_list = []
    pip_list = []
    items_list = []
    for key in state_dict:
        items_list.append(state_dict.get(key))
    
    for lst in items_list:
        gdpp_list.append(lst[len(lst)-2])
    
    for lst in items_list:
        pip_list.append(lst[len(lst)-1])
        
    
    gdpp_list_sorted = sorted(gdpp_list)
    pip_list_sorted = sorted(pip_list)
    min_gdpp = gdpp_list_sorted[len(gdpp_list_sorted) - 1]
    min_pip = pip_list_sorted[len(pip_list_sorted)-1]

    for key in state_dict:
        if min_gdpp in state_dict.get(key):
            gdpp_tupl = (key, min_gdpp)
    
    for key in state_dict:
        if min_pip in state_dict.get(key):
            pip_tupl = (key, min_pip)
    
    return gdpp_tupl, pip_tupl

def get_min(state_dict):
    gdpp_list = []
    pip_list = []
    items_list = []
    for key in state_dict:
        items_list.append(state_dict.get(key))
    
    for lst in items_list:
        gdpp_list.append(lst[len(lst)-2])
    
    for lst in items_list:
        pip_list.append(lst[len(lst)-1])
    
    gdpp_list_sorted = sorted(gdpp_list, reverse = True)
    pip_list_sorted = sorted(pip_list, reverse = True)
    min_gdpp = gdpp_list_sorted[len(gdpp_list_sorted) - 1]
    min_pip = pip_list_sorted[len(pip_list_sorted) - 1]
    
    for key in state_dict:
        if min_gdpp in state_dict.get(key):
            gdpp_tupl = (key, min_gdpp)
    
    for key in state_dict:
        if min_pip in state_dict.get(key):
            pip_tupl = (key, min_pip)
    
    return gdpp_tupl, pip_tupl

def print_info(state_dict, max_gdpp, max_pip, min_gdpp, min_pip):
    
    fp2 = open('text.txt','wt')

    print('\n{} has the highest GDP per capita at ${:,.2f}'.format(max_gdpp[0], max_gdpp[1]), file = fp2)
    print('{} has the highest GDP per capita at ${:,.2f}\n'.format(min_gdpp[0], min_gdpp[1]), file = fp2)
    print('{} has the highest income per capita at ${:,.2f}'.format(max_pip[0], max_pip[1]), file = fp2)
    print('{} has the lowest income per capita at ${:,.2f}\n'.format(min_pip[0], min_pip[1]), file = fp2)
    
    format_list = ['State', 'Population(m)', 'GDP(b)', 'Income(b)', 'Subsidies', 'Compensation(b)','Taxes', 'GDPp', 'IncomeP','TaxProd/Imp(b)']
    print("{:10} {:14} {:10} {:10} {:10} {:10} {:10} {:10} {:13}".format(format_list[0], format_list[1], format_list[2], format_list[3], format_list[4], format_list[5], format_list[6], format_list[7], format_list[8]), file= fp2)

    for key in state_dict:
        lst = state_dict.get(key)
        print("{:14} {:>10,.2f} {:>10,.2f} {:>10,.2f} {:>10,.2f} {:>10,.2f} {:>10,.2f} {:>13,.2f} {:>13,.2f}".format(key, lst[0], lst[1], lst[2], lst[3], lst[4], lst[5], lst[6], lst[7]), file = fp2)
        lst = []



def get_x_coord(state_dict, plot_data):
    vals_dict = {'Pop':0, 'GDP':1, 'PI':2, 'Sub':3, 'CE':4, 'TPI':5, 'GDPp':6, 'Pip':7}
    plot_data.strip()
    coords = plot_data.split(',')
    x = coords[0].lower()
    
    x_coords_list = []
    
    for key in vals_dict:
        if x == key.lower():
            index_num_x = vals_dict.get(key)
            for key2 in state_dict:
                lst = state_dict.get(key2)
                x_coords_list.append(lst[index_num_x])
                lst = []
    return x_coords_list

def get_y_coord(state_dict, plot_data):
    vals_dict = {'Pop':0, 'GDP':1, 'PI':2, 'Sub':3, 'CE':4, 'TPI':5, 'GDPp':6, 'Pip':7}
    plot_data.strip()
    coords = plot_data.split(',')
    y = coords[1].lower()
    
    y_coords_list = []
    
    for key in vals_dict:
        if y == key.lower():
            index_num_y = vals_dict.get(key)
            for key2 in state_dict:
                lst = state_dict.get(key2)
                y_coords_list.append(lst[index_num_y])
                lst = []
    return y_coords_list
    

def plot_data(state_dict, x_coords_list, y_coords_list):

    states_list = []
    for key in state_dict:
        states_list.append(key)

    for state_index_num,state_name in enumerate(states_list):
        pylab.annotate(state_name, (x_coords_list[state_index_num],y_coords_list[state_index_num]))

    pylab.scatter(x_coords_list, y_coords_list)
    pylab.savefig("plot.png")



def regression_line(plot_data, sd, x, y):
    x = get_x_coord(sd, plot_data)
    y = get_y_coord(sd, plot_data)
    xarr = pylab.array(x) 
    yarr = pylab.array(y) 
    m,b = pylab.polyfit(xarr,yarr, deg = 1) 
 
    pylab.plot(xarr,m*xarr + b, '-')
    pylab.savefig("plot.png")

def main():
    fp = open_file()
    states_dictionary = read_file(fp)
    
    max_gdpp, max_pip = get_max(states_dictionary)
    min_gdpp, min_pip = get_min(states_dictionary)
    print_info(states_dictionary, max_gdpp, max_pip, min_gdpp, min_pip)
    plot_prompt = input("Do you want to create a plot? ")
    if plot_prompt.lower() == 'yes':
        plot_data_prompt = input('Enter what x and y values you want to plot (x,y) [Pop,GDP,PI,Sub,CE,TPI,GDPp,Pip]: ')
        x_coords_list = get_x_coord(states_dictionary, plot_data_prompt)
        y_coords_list = get_y_coord(states_dictionary, plot_data_prompt)
        plot_data(states_dictionary, x_coords_list, y_coords_list)
        regression_line(plot_data_prompt,states_dictionary, x_coords_list, y_coords_list)

main()
    



